#include<stdio.h>
int int main(int argc, char const *argv[])
{
	printf("Preetam");
	return 0;
}