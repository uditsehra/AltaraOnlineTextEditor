from django.apps import AppConfig


class TexteditorConfig(AppConfig):
    name = 'textEditor'
